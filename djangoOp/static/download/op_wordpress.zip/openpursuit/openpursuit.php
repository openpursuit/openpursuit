<?php
/*
Plugin Name: OpenPursuit
Plugin URI: http://www.openpursuit.org
Description: A quiz flash game based on the Openpursuit quiz archive.
Version: The plugin's Version Number, e.g.: 1.0
Author: OrazioPirataDelloSpazio
Author URI: http://www.bzzauz.org
*/
?><?php
/*  Copyright YEAR  OrazioPirataDelloSpazio  (email : ziducaixao - a t - autistici.org)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
?><?
$topic = "\"topic=reti\"";

function openpursuit() 
{
?><a href="http://www.openpursuit.org"></a>
<!--text used in the movie-->
<!--
waiting...
You Win
Get another question
Change the topic of the quiz:
Your score is:
0
not yet implemented :-)
You Lose
-->
<!-- saved from url=(0013)about:internet -->
<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="220" height="220" id="opflashwidget" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="opflashwidget.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#ffffff" /><embed src="http://www.openpursuit.org/media/flash/opflashwidget.swf" FlashVars=<? print $topic ?> quality="high" bgcolor="#ffffff" width="220" height="220" name="opflashwidget" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object><?
}

function widget_OP($args) {
  extract($args);
  echo $before_widget;
  echo $before_title;?>OpenPursuit<?php echo $after_title;
  openpursuit();
  echo $after_widget;
}

function openpursuit_init()
{
  register_sidebar_widget(__('OpenPursuit'), 'widget_OP');     
}
add_action("plugins_loaded", "openpursuit_init");
?>